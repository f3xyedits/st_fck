import sys, os, math, time

### Classes instead of packages & modules to fit all in one file ###
class Util:
    class File:
        @staticmethod
        def read(path):
            try:
                f = open(path, 'r')
                lines = f.readlines()
                f.close()
                return lines
            except:
                pass

        @staticmethod
        def write(path, name, id, time):
            f = open(path, 'a+')
            f.write("Name=%s\n" % (name))
            f.write("ID=%i\n" % (id))
            f.write("Time=%i\n\n" % (time))
            f.close()

        @classmethod
        def removeLastLines(cls, path, num):
            allLines = cls.read(path)
            f = open(path, "w+")
            f.writelines(allLines[:-num])
            f.close()

    class Module:
        @classmethod
        def find(cls, name, atr):
            for module_name in sys.modules:
                if name == '*' or name in module_name:
                    try:
                        module = __import__(module_name)
                        getattr(module, atr)
                        return module
                    except:
                        pass

            return cls.find('*', atr)

        @staticmethod
        def dump(path):
            for m in sys.modules:
                f = open(path, 'a+')
                
                try:
                    module = __import__(m)

                    f.write("\n# %s\nimport %s\n" % (m, m))

                    for atr in dir(module):
                        atr_name = atr
                        atr = getattr(module, atr)

                        if callable(atr):
                            f.write("%s.%s() # %s\n" % (m, atr_name, type(atr)))
                            for sub_atr in ['__code__', '__defaults__', '__kwdefaults__']:
                                if sub_atr == '__code__':
                                    for co_atr in ['co_argcount', 'co_varnames', 'co_nlocals', 'co_names', 'co_cellvars', 'co_consts', 'co_freevars', 'co_posonlyargcount', 'co_kwonlyargcount']:
                                        try:
                                            f.write("%s.%s.%s.%s = %s\n" % (m, atr_name, sub_atr, co_atr, getattr(getattr(atr, sub_atr), co_atr)))
                                        except:
                                            pass
                                else:
                                    try:
                                        f.write("%s.%s.%s = %s\n" % (m, atr_name, sub_atr, getattr(atr, sub_atr)))
                                    except:
                                        pass
                        else:
                            f.write("%s.%s # %s\n" % (m, atr_name, type(atr)))
                except:
                    f.write("\n# ImportError: No module named %s\n" % (m))

                f.close()

### Import Metin2 modules ###
app = Util.Module.find('app', 'GetRandom')
item = Util.Module.find('item', 'GetItemName')
chr = Util.Module.find('chr', 'SetRotation')
chrmgr = Util.Module.find('chrmgr', 'SetMovingSpeed')
net = Util.Module.find('net', 'SendChatPacket')
player = Util.Module.find('player', 'SetAttackKeyState')
ui = Util.Module.find('ui', 'ThinBoard')
textTail = Util.Module.find('textTail', 'Pick')
chat = Util.Module.find('chat', 'AppendChat')
systemSetting = Util.Module.find('systemSetting', 'GetCurrentResolution')
playerSettingModule = Util.Module.find('playerSettingModule', 'SetGeneralMotions')
skill = Util.Module.find('skill', 'GetSkillName')
wndMgr = Util.Module.find('wndMgr', 'GetScreenWidth')
dbg = Util.Module.find('dbg', 'LogBox')
background = Util.Module.find('background', 'LoadMap')
shop = Util.Module.find('shop', 'IsPrivateShop')
grp = Util.Module.find('grp', 'SetInterfaceRenderState')
snd = Util.Module.find('snd', 'PlaySound')
effect = Util.Module.find('effect', 'SetPosition')
quest = Util.Module.find('quest', 'GetQuestIndex')
guild = Util.Module.find('guild', 'GetGuildLevel')

ime = Util.Module.find('ime', 'MoveLeft')
miniMap = Util.Module.find('miniMap', 'GetGuildAreaID')

import game,emotion,uiParty
from m2kmod.Modules.pyDetour import DetourFunction, DetourClass

	
def GetCurrentText(self):
	return self.textLine.GetText()
	
def OnSelectItem(self, index, name):
	self.SetCurrentItem(name)
	self.CloseListBox()
	
def GetSelectedIndex(self):
	return self.listBox.GetSelectedItem()
	
def HookedQuestWindow(data):
	pass
	

	
	
def PartyButton(self):
	dbg.LogBox("test")
	self.isShowStateButton = TRUE

	(x, y) = self.GetGlobalPosition()
	xPos = x + 110

	skillLevel = self.__GetPartySkillLevel()

	## Tanker
	if skillLevel >= 10:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_ATTACKER)
		xPos += 23

	## Attacker
	if skillLevel >= 20:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_BERSERKER)
		xPos += 23

	## Tanker
	if skillLevel >= 20:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_TANKER)
		xPos += 23

	# Buffer
	if skillLevel >= 25:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_BUFFER)
		xPos += 23

	## Skill Master
	if skillLevel >= 35:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_SKILL_MASTER)
		xPos += 23

	## Defender
	if skillLevel >= 40:
		self.__AppendStateButton(xPos, y, player.PARTY_STATE_DEFENDER)
		xPos += 23

	## Warp
	if skillLevel >= 35:
		if self.stateButtonDict.has_key(self.MEMBER_BUTTON_WARP):
			button = self.stateButtonDict[self.MEMBER_BUTTON_WARP]
			button.SetPosition(xPos, y)
			button.Show()
			xPos += 23

	## Expel
	if self.stateButtonDict.has_key(self.MEMBER_BUTTON_EXPEL):
		button = self.stateButtonDict[self.MEMBER_BUTTON_EXPEL]
		button.SetPosition(xPos, y)
		button.Show()
		xPos += 23
		

		
		
detour_questwindow = DetourFunction(game.GameWindow.OpenQuestWindow, HookedQuestWindow)

def SetComboHook():
	ui.ComboBox.GetCurrentText = GetCurrentText
	ui.ComboBox.GetSelectedIndex = GetSelectedIndex
	ui.ComboBox.OnSelectItem = OnSelectItem	
	
def SetQuestHook(arg):
	if arg:
		detour_questwindow.attach()
	else:
		detour_questwindow.detach()
			
def SetPartyWarpEnable():
	#oldPartyMemberInfoBoard = uiParty.PartyMemberInfoBoard
	#uiParty.PartyMemberInfoBoard = PartyMemberInfoBoard
	uiParty.PartyMemberInfoBoard.__ShowStateButton = PartyButton
	dbg.LogBox("test")
